Insert Into local_publico values (-37.9897085462343, 85.20330953621628, 'city0');

Insert Into local_publico values (72.0899916363071, 41.61691938164842, 'city1');

Insert Into local_publico values (87.13824773495128, 101.14030755636479, 'city2');

Insert Into local_publico values (-16.250131179113012, 95.99187443069272, 'city3');

Insert Into local_publico values (65.49278640036664, 51.870319019507534, 'city4');

Insert Into local_publico values (-34.29395621866966, 92.41488589531669, 'city5');

Insert Into local_publico values (-41.63375362862657, 33.83918828355373, 'city6');

Insert Into local_publico values (69.61319477940356, 62.70951289716583, 'city7');

Insert Into local_publico values (-64.17447853835246, 37.82225316048255, 'city8');

Insert Into local_publico values (-57.04176064527869, 24.865667764637493, 'city9');

Insert Into local_publico values (-39.737653613301255, 66.83141424058836, 'city10');

Insert Into local_publico values (-70.255079555268, 179.71820620520444, 'city11');

Insert Into local_publico values (-27.93425707330917, 68.39031136115901, 'city12');

Insert Into local_publico values (19.10889195214122, 86.21071751224473, 'city13');

Insert Into local_publico values (-7.890675896623662, 118.91485095151315, 'city14');

Insert Into item (descricao, localizacao, latitude, longitude) values ( 'descricao0', 'localizacao0', -70.255079555268, 179.71820620520444);

Insert Into item (descricao, localizacao, latitude, longitude) values ( 'descricao1', 'localizacao1', -39.737653613301255, 66.83141424058836);

Insert Into item (descricao, localizacao, latitude, longitude) values ( 'descricao2', 'localizacao2', -37.9897085462343, 85.20330953621628);

Insert Into item (descricao, localizacao, latitude, longitude) values ( 'descricao3', 'localizacao3', 69.61319477940356, 62.70951289716583);

Insert Into item (descricao, localizacao, latitude, longitude) values ( 'descricao4', 'localizacao4', -37.9897085462343, 85.20330953621628);

Insert Into item (descricao, localizacao, latitude, longitude) values ( 'descricao5', 'localizacao5', -41.63375362862657, 33.83918828355373);

Insert Into item (descricao, localizacao, latitude, longitude) values ( 'descricao6', 'localizacao6', -34.29395621866966, 92.41488589531669);

Insert Into item (descricao, localizacao, latitude, longitude) values ( 'descricao7', 'localizacao7', -34.29395621866966, 92.41488589531669);

Insert Into item (descricao, localizacao, latitude, longitude) values ( 'descricao8', 'localizacao8', 69.61319477940356, 62.70951289716583);

Insert Into item (descricao, localizacao, latitude, longitude) values ( 'descricao9', 'localizacao9', -57.04176064527869, 24.865667764637493);

Insert Into item (descricao, localizacao, latitude, longitude) values ( 'descricao10', 'localizacao10', -70.255079555268, 179.71820620520444);

Insert Into item (descricao, localizacao, latitude, longitude) values ( 'descricao11', 'localizacao11', -57.04176064527869, 24.865667764637493);

Insert Into item (descricao, localizacao, latitude, longitude) values ( 'descricao12', 'localizacao12', -7.890675896623662, 118.91485095151315);

Insert Into item (descricao, localizacao, latitude, longitude) values ( 'descricao13', 'localizacao13', 65.49278640036664, 51.870319019507534);

Insert Into item (descricao, localizacao, latitude, longitude) values ( 'descricao14', 'localizacao14', -34.29395621866966, 92.41488589531669);

Insert Into item (descricao, localizacao, latitude, longitude) values ( 'descricao15', 'localizacao15', -7.890675896623662, 118.91485095151315);

Insert Into item (descricao, localizacao, latitude, longitude) values ( 'descricao16', 'localizacao16', 19.10889195214122, 86.21071751224473);

Insert Into item (descricao, localizacao, latitude, longitude) values ( 'descricao17', 'localizacao17', 65.49278640036664, 51.870319019507534);

Insert Into item (descricao, localizacao, latitude, longitude) values ( 'descricao18', 'localizacao18', -37.9897085462343, 85.20330953621628);

Insert Into item (descricao, localizacao, latitude, longitude) values ( 'descricao19', 'localizacao19', -57.04176064527869, 24.865667764637493);

Insert Into item (descricao, localizacao, latitude, longitude) values ( 'descricao20', 'localizacao20', -27.93425707330917, 68.39031136115901);

Insert Into item (descricao, localizacao, latitude, longitude) values ( 'descricao21', 'localizacao21', 19.10889195214122, 86.21071751224473);

Insert Into item (descricao, localizacao, latitude, longitude) values ( 'descricao22', 'localizacao22', -16.250131179113012, 95.99187443069272);

Insert Into item (descricao, localizacao, latitude, longitude) values ( 'descricao23', 'localizacao23', -39.737653613301255, 66.83141424058836);

Insert Into item (descricao, localizacao, latitude, longitude) values ( 'descricao24', 'localizacao24', -7.890675896623662, 118.91485095151315);

Insert Into item (descricao, localizacao, latitude, longitude) values ( 'descricao25', 'localizacao25', -57.04176064527869, 24.865667764637493);

Insert Into item (descricao, localizacao, latitude, longitude) values ( 'descricao26', 'localizacao26', -7.890675896623662, 118.91485095151315);

Insert Into item (descricao, localizacao, latitude, longitude) values ( 'descricao27', 'localizacao27', -39.737653613301255, 66.83141424058836);

Insert Into item (descricao, localizacao, latitude, longitude) values ( 'descricao28', 'localizacao28', -16.250131179113012, 95.99187443069272);

Insert Into item (descricao, localizacao, latitude, longitude) values ( 'descricao29', 'localizacao29', 19.10889195214122, 86.21071751224473);

Insert Into anomalia (zona, imagem, lingua, ts, descricao, tem_anomalia_redacao) values ( 'zona_0', 'imagem0', 'lingua_0', '2017-04-23 18:10:11', 'descricao0', False);

Insert Into anomalia_traducao (zona2, lingua2) values ( 'zona2_0', 'lingua2_0');

Insert Into anomalia (zona, imagem, lingua, ts, descricao, tem_anomalia_redacao) values ( 'zona_1', 'imagem1', 'lingua_1', '2019-10-23 17:10:11', 'descricao1', True);

Insert Into anomalia (zona, imagem, lingua, ts, descricao, tem_anomalia_redacao) values ( 'zona_2', 'imagem2', 'lingua_2', '2019-04-23 15:10:11', 'descricao2', True);

Insert Into anomalia (zona, imagem, lingua, ts, descricao, tem_anomalia_redacao) values ( 'zona_3', 'imagem3', 'lingua_3', '2018-07-23 15:10:11', 'descricao3', False);

Insert Into anomalia_traducao (zona2, lingua2) values ( 'zona2_3', 'lingua2_3');

Insert Into anomalia (zona, imagem, lingua, ts, descricao, tem_anomalia_redacao) values ( 'zona_4', 'imagem4', 'lingua_4', '2015-04-23 17:10:11', 'descricao4', False);

Insert Into anomalia_traducao (zona2, lingua2) values ( 'zona2_4', 'lingua2_4');

Insert Into anomalia (zona, imagem, lingua, ts, descricao, tem_anomalia_redacao) values ( 'zona_5', 'imagem5', 'lingua_5', '2018-07-23 13:10:11', 'descricao5', False);

Insert Into anomalia_traducao (zona2, lingua2) values ( 'zona2_5', 'lingua2_5');

Insert Into anomalia (zona, imagem, lingua, ts, descricao, tem_anomalia_redacao) values ( 'zona_6', 'imagem6', 'lingua_6', '2018-04-23 13:10:11', 'descricao6', True);

Insert Into anomalia (zona, imagem, lingua, ts, descricao, tem_anomalia_redacao) values ( 'zona_7', 'imagem7', 'lingua_7', '2019-11-23 15:10:11', 'descricao7', True);

Insert Into anomalia (zona, imagem, lingua, ts, descricao, tem_anomalia_redacao) values ( 'zona_8', 'imagem8', 'lingua_8', '2015-04-23 17:10:11', 'descricao8', False);

Insert Into anomalia_traducao (zona2, lingua2) values ( 'zona2_8', 'lingua2_8');

Insert Into anomalia (zona, imagem, lingua, ts, descricao, tem_anomalia_redacao) values ( 'zona_9', 'imagem9', 'lingua_9', '2018-04-23 14:10:11', 'descricao9', False);

Insert Into anomalia_traducao (zona2, lingua2) values ( 'zona2_9', 'lingua2_9');

Insert Into anomalia (zona, imagem, lingua, ts, descricao, tem_anomalia_redacao) values ( 'zona_10', 'imagem10', 'lingua_10', '2019-04-23 14:10:11', 'descricao10', False);

Insert Into anomalia_traducao (zona2, lingua2) values ( 'zona2_10', 'lingua2_10');

Insert Into anomalia (zona, imagem, lingua, ts, descricao, tem_anomalia_redacao) values ( 'zona_11', 'imagem11', 'lingua_11', '2019-11-23 18:10:11', 'descricao11', True);

Insert Into anomalia (zona, imagem, lingua, ts, descricao, tem_anomalia_redacao) values ( 'zona_12', 'imagem12', 'lingua_12', '2017-04-23 18:10:11', 'descricao12', False);

Insert Into anomalia_traducao (zona2, lingua2) values ( 'zona2_12', 'lingua2_12');

Insert Into anomalia (zona, imagem, lingua, ts, descricao, tem_anomalia_redacao) values ( 'zona_13', 'imagem13', 'lingua_13', '2017-07-23 13:10:11', 'descricao13', False);

Insert Into anomalia_traducao (zona2, lingua2) values ( 'zona2_13', 'lingua2_13');

Insert Into anomalia (zona, imagem, lingua, ts, descricao, tem_anomalia_redacao) values ( 'zona_14', 'imagem14', 'lingua_14', '2017-07-23 17:10:11', 'descricao14', False);

Insert Into anomalia_traducao (zona2, lingua2) values ( 'zona2_14', 'lingua2_14');

Insert Into anomalia (zona, imagem, lingua, ts, descricao, tem_anomalia_redacao) values ( 'zona_15', 'imagem15', 'lingua_15', '2018-04-23 13:10:11', 'descricao15', True);

Insert Into anomalia (zona, imagem, lingua, ts, descricao, tem_anomalia_redacao) values ( 'zona_16', 'imagem16', 'lingua_16', '2017-07-23 15:10:11', 'descricao16', True);

Insert Into anomalia (zona, imagem, lingua, ts, descricao, tem_anomalia_redacao) values ( 'zona_17', 'imagem17', 'lingua_17', '2017-04-23 16:10:11', 'descricao17', True);

Insert Into anomalia (zona, imagem, lingua, ts, descricao, tem_anomalia_redacao) values ( 'zona_18', 'imagem18', 'lingua_18', '2019-11-23 15:10:11', 'descricao18', True);

Insert Into anomalia (zona, imagem, lingua, ts, descricao, tem_anomalia_redacao) values ( 'zona_19', 'imagem19', 'lingua_19', '2019-10-23 17:10:11', 'descricao19', False);

Insert Into anomalia_traducao (zona2, lingua2) values ( 'zona2_19', 'lingua2_19');

Insert Into anomalia (zona, imagem, lingua, ts, descricao, tem_anomalia_redacao) values ( 'zona_20', 'imagem20', 'lingua_20', '2017-07-23 15:10:11', 'descricao20', False);

Insert Into anomalia_traducao (zona2, lingua2) values ( 'zona2_20', 'lingua2_20');

Insert Into anomalia (zona, imagem, lingua, ts, descricao, tem_anomalia_redacao) values ( 'zona_21', 'imagem21', 'lingua_21', '2017-07-23 16:10:11', 'descricao21', False);

Insert Into anomalia_traducao (zona2, lingua2) values ( 'zona2_21', 'lingua2_21');

Insert Into anomalia (zona, imagem, lingua, ts, descricao, tem_anomalia_redacao) values ( 'zona_22', 'imagem22', 'lingua_22', '2019-04-23 15:10:11', 'descricao22', True);

Insert Into anomalia (zona, imagem, lingua, ts, descricao, tem_anomalia_redacao) values ( 'zona_23', 'imagem23', 'lingua_23', '2019-11-23 18:10:11', 'descricao23', False);

Insert Into anomalia_traducao (zona2, lingua2) values ( 'zona2_23', 'lingua2_23');

Insert Into anomalia (zona, imagem, lingua, ts, descricao, tem_anomalia_redacao) values ( 'zona_24', 'imagem24', 'lingua_24', '2019-04-23 14:10:11', 'descricao24', False);

Insert Into anomalia_traducao (zona2, lingua2) values ( 'zona2_24', 'lingua2_24');

Insert Into anomalia (zona, imagem, lingua, ts, descricao, tem_anomalia_redacao) values ( 'zona_25', 'imagem25', 'lingua_25', '2017-07-23 15:10:11', 'descricao25', True);

Insert Into anomalia (zona, imagem, lingua, ts, descricao, tem_anomalia_redacao) values ( 'zona_26', 'imagem26', 'lingua_26', '2018-07-23 17:10:11', 'descricao26', True);

Insert Into anomalia (zona, imagem, lingua, ts, descricao, tem_anomalia_redacao) values ( 'zona_27', 'imagem27', 'lingua_27', '2019-09-13 13:10:11', 'descricao27', False);

Insert Into anomalia_traducao (zona2, lingua2) values ( 'zona2_27', 'lingua2_27');

Insert Into anomalia (zona, imagem, lingua, ts, descricao, tem_anomalia_redacao) values ( 'zona_28', 'imagem28', 'lingua_28', '2019-04-23 15:10:11', 'descricao28', True);

Insert Into anomalia (zona, imagem, lingua, ts, descricao, tem_anomalia_redacao) values ( 'zona_29', 'imagem29', 'lingua_29', '2018-07-23 13:10:11', 'descricao29', True);

Insert Into duplicado values (0, 10);

Insert Into duplicado values (1, 23);

Insert Into duplicado values (1, 27);

Insert Into duplicado values (2, 4);

Insert Into duplicado values (2, 18);

Insert Into duplicado values (3, 8);

Insert Into duplicado values (4, 18);

Insert Into duplicado values (6, 7);

Insert Into duplicado values (6, 14);

Insert Into duplicado values (7, 14);

Insert Into duplicado values (9, 11);

Insert Into duplicado values (9, 19);

Insert Into duplicado values (9, 25);

Insert Into duplicado values (11, 19);

Insert Into duplicado values (11, 25);

Insert Into duplicado values (12, 15);

Insert Into duplicado values (12, 24);

Insert Into duplicado values (12, 26);

Insert Into duplicado values (13, 17);

Insert Into duplicado values (15, 24);

Insert Into duplicado values (15, 26);

Insert Into duplicado values (16, 21);

Insert Into duplicado values (16, 29);

Insert Into duplicado values (19, 25);

Insert Into duplicado values (21, 29);

Insert Into duplicado values (22, 28);

Insert Into duplicado values (23, 27);

Insert Into duplicado values (24, 26);

Insert Into utilizador values ( 'email0@bd.com', 'password0');

Insert Into utilizador_regular values ( 'email0@bd.com');

Insert Into utilizador values ( 'email1@bd.com', 'password1');

Insert Into utilizador_regular values ( 'email1@bd.com');

Insert Into utilizador values ( 'email2@bd.com', 'password2');

Insert Into utilizador_regular values ( 'email2@bd.com');

Insert Into utilizador values ( 'email3@bd.com', 'password3');

Insert Into utilizador_qualificado values ( 'email3@bd.com');

Insert Into utilizador values ( 'email4@bd.com', 'password4');

Insert Into utilizador_regular values ( 'email4@bd.com');

Insert Into utilizador values ( 'email5@bd.com', 'password5');

Insert Into utilizador_regular values ( 'email5@bd.com');

Insert Into utilizador values ( 'email6@bd.com', 'password6');

Insert Into utilizador_regular values ( 'email6@bd.com');

Insert Into utilizador values ( 'email7@bd.com', 'password7');

Insert Into utilizador_qualificado values ( 'email7@bd.com');

Insert Into utilizador values ( 'email8@bd.com', 'password8');

Insert Into utilizador_regular values ( 'email8@bd.com');

Insert Into utilizador values ( 'email9@bd.com', 'password9');

Insert Into utilizador_qualificado values ( 'email9@bd.com');

Insert Into utilizador values ( 'email10@bd.com', 'password10');

Insert Into utilizador_regular values ( 'email10@bd.com');

Insert Into utilizador values ( 'email11@bd.com', 'password11');

Insert Into utilizador_qualificado values ( 'email11@bd.com');

Insert Into utilizador values ( 'email12@bd.com', 'password12');

Insert Into utilizador_regular values ( 'email12@bd.com');

Insert Into utilizador values ( 'email13@bd.com', 'password13');

Insert Into utilizador_qualificado values ( 'email13@bd.com');

Insert Into utilizador values ( 'email14@bd.com', 'password14');

Insert Into utilizador_regular values ( 'email14@bd.com');

Insert Into utilizador values ( 'email15@bd.com', 'password15');

Insert Into utilizador_qualificado values ( 'email15@bd.com');

Insert Into utilizador values ( 'email16@bd.com', 'password16');

Insert Into utilizador_regular values ( 'email16@bd.com');

Insert Into utilizador values ( 'email17@bd.com', 'password17');

Insert Into utilizador_qualificado values ( 'email17@bd.com');

Insert Into utilizador values ( 'email18@bd.com', 'password18');

Insert Into utilizador_regular values ( 'email18@bd.com');

Insert Into utilizador values ( 'email19@bd.com', 'password19');

Insert Into utilizador_regular values ( 'email19@bd.com');

Insert Into utilizador values ( 'email20@bd.com', 'password20');

Insert Into utilizador_regular values ( 'email20@bd.com');

Insert Into utilizador values ( 'email21@bd.com', 'password21');

Insert Into utilizador_regular values ( 'email21@bd.com');

Insert Into utilizador values ( 'email22@bd.com', 'password22');

Insert Into utilizador_regular values ( 'email22@bd.com');

Insert Into utilizador values ( 'email23@bd.com', 'password23');

Insert Into utilizador_qualificado values ( 'email23@bd.com');

Insert Into utilizador values ( 'email24@bd.com', 'password24');

Insert Into utilizador_regular values ( 'email24@bd.com');

Insert Into utilizador values ( 'email25@bd.com', 'password25');

Insert Into utilizador_qualificado values ( 'email25@bd.com');

Insert Into utilizador values ( 'email26@bd.com', 'password26');

Insert Into utilizador_regular values ( 'email26@bd.com');

Insert Into utilizador values ( 'email27@bd.com', 'password27');

Insert Into utilizador_qualificado values ( 'email27@bd.com');

Insert Into utilizador values ( 'email28@bd.com', 'password28');

Insert Into utilizador_regular values ( 'email28@bd.com');

Insert Into utilizador values ( 'email29@bd.com', 'password29');

Insert Into utilizador_qualificado values ( 'email29@bd.com');

Insert Into incidencia values (0, 9, 'email25@bd.com');

Insert Into incidencia values (1, 14, 'email17@bd.com');

Insert Into incidencia values (2, 1, 'email20@bd.com');

Insert Into incidencia values (3, 3, 'email3@bd.com');

Insert Into incidencia values (4, 9, 'email26@bd.com');

Insert Into incidencia values (5, 14, 'email16@bd.com');

Insert Into incidencia values (6, 29, 'email7@bd.com');

Insert Into incidencia values (7, 5, 'email20@bd.com');

Insert Into incidencia values (8, 1, 'email26@bd.com');

Insert Into incidencia values (9, 29, 'email12@bd.com');

Insert Into incidencia values (10, 11, 'email11@bd.com');

Insert Into incidencia values (11, 16, 'email24@bd.com');

Insert Into incidencia values (12, 6, 'email5@bd.com');

Insert Into incidencia values (13, 5, 'email6@bd.com');

Insert Into incidencia values (14, 22, 'email25@bd.com');

Insert Into incidencia values (15, 19, 'email21@bd.com');

Insert Into incidencia values (16, 19, 'email19@bd.com');

Insert Into incidencia values (17, 7, 'email14@bd.com');

Insert Into incidencia values (18, 26, 'email19@bd.com');

Insert Into incidencia values (19, 26, 'email18@bd.com');

Insert Into incidencia values (20, 20, 'email5@bd.com');

Insert Into incidencia values (21, 29, 'email19@bd.com');

Insert Into incidencia values (22, 15, 'email8@bd.com');

Insert Into incidencia values (23, 21, 'email24@bd.com');

Insert Into incidencia values (24, 19, 'email19@bd.com');

Insert Into incidencia values (25, 27, 'email28@bd.com');

Insert Into incidencia values (26, 1, 'email18@bd.com');

Insert Into incidencia values (27, 17, 'email2@bd.com');

Insert Into incidencia values (28, 6, 'email25@bd.com');

Insert Into incidencia values (29, 21, 'email16@bd.com');

Insert Into proposta_de_correcao(email, data_hora, texto) values ('email7@bd.com', '2018-07-23 18:10:11', 'texto0');

Insert Into correcao(email, anomalia_id) values ('email7@bd.com', 9);

Insert Into proposta_de_correcao(email, data_hora, texto) values ('email3@bd.com', '2018-04-23 13:10:11', 'texto1');

Insert Into correcao(email, anomalia_id) values ('email3@bd.com', 17);

Insert Into proposta_de_correcao(email, data_hora, texto) values ('email23@bd.com', '2018-04-23 13:10:11', 'texto2');

Insert Into correcao(email, anomalia_id) values ('email23@bd.com', 15);

Insert Into proposta_de_correcao(email, data_hora, texto) values ('email7@bd.com', '2018-07-23 16:10:11', 'texto3');

Insert Into correcao(email, anomalia_id) values ('email7@bd.com', 9);

Insert Into proposta_de_correcao(email, data_hora, texto) values ('email27@bd.com', '2019-04-23 15:10:11', 'texto4');

Insert Into correcao(email, anomalia_id) values ('email27@bd.com', 19);

Insert Into proposta_de_correcao(email, data_hora, texto) values ('email27@bd.com', '2017-07-23 13:10:11', 'texto5');

Insert Into correcao(email, anomalia_id) values ('email27@bd.com', 27);

Insert Into proposta_de_correcao(email, data_hora, texto) values ('email11@bd.com', '2019-11-23 15:10:11', 'texto6');

Insert Into correcao(email, anomalia_id) values ('email11@bd.com', 2);

Insert Into proposta_de_correcao(email, data_hora, texto) values ('email25@bd.com', '2015-04-23 17:10:11', 'texto7');

Insert Into correcao(email, anomalia_id) values ('email25@bd.com', 15);

Insert Into proposta_de_correcao(email, data_hora, texto) values ('email13@bd.com', '2017-07-23 16:10:11', 'texto8');

Insert Into correcao(email, anomalia_id) values ('email13@bd.com', 17);

Insert Into proposta_de_correcao(email, data_hora, texto) values ('email13@bd.com', '2018-07-23 13:10:11', 'texto9');

Insert Into correcao(email, anomalia_id) values ('email13@bd.com', 27);

Insert Into proposta_de_correcao(email, data_hora, texto) values ('email13@bd.com', '2017-07-23 17:10:11', 'texto10');

Insert Into correcao(email, anomalia_id) values ('email13@bd.com', 10);

Insert Into proposta_de_correcao(email, data_hora, texto) values ('email27@bd.com', '2018-07-23 13:10:11', 'texto11');

Insert Into correcao(email, anomalia_id) values ('email27@bd.com', 3);

Insert Into proposta_de_correcao(email, data_hora, texto) values ('email15@bd.com', '2017-07-23 14:10:11', 'texto12');

Insert Into correcao(email, anomalia_id) values ('email15@bd.com', 7);

Insert Into proposta_de_correcao(email, data_hora, texto) values ('email15@bd.com', '2019-04-23 14:10:11', 'texto13');

Insert Into correcao(email, anomalia_id) values ('email15@bd.com', 22);

Insert Into proposta_de_correcao(email, data_hora, texto) values ('email9@bd.com', '2017-07-23 18:10:11', 'texto14');

Insert Into correcao(email, anomalia_id) values ('email9@bd.com', 1);

Insert Into proposta_de_correcao(email, data_hora, texto) values ('email15@bd.com', '2018-07-23 15:10:11', 'texto15');

Insert Into correcao(email, anomalia_id) values ('email15@bd.com', 29);

Insert Into proposta_de_correcao(email, data_hora, texto) values ('email7@bd.com', '2019-04-23 15:10:11', 'texto16');

Insert Into correcao(email, anomalia_id) values ('email7@bd.com', 16);

Insert Into proposta_de_correcao(email, data_hora, texto) values ('email15@bd.com', '2019-09-23 16:10:11', 'texto17');

Insert Into correcao(email, anomalia_id) values ('email15@bd.com', 30);

Insert Into proposta_de_correcao(email, data_hora, texto) values ('email9@bd.com', '2018-07-23 18:10:11', 'texto18');

Insert Into correcao(email, anomalia_id) values ('email9@bd.com', 14);

Insert Into proposta_de_correcao(email, data_hora, texto) values ('email27@bd.com', '2016-04-23 18:10:11', 'texto19');

Insert Into correcao(email, anomalia_id) values ('email27@bd.com', 29);

Insert Into proposta_de_correcao(email, data_hora, texto) values ('email27@bd.com', '2017-04-23 16:10:11', 'texto20');

Insert Into correcao(email, anomalia_id) values ('email27@bd.com', 18);

Insert Into proposta_de_correcao(email, data_hora, texto) values ('email3@bd.com', '2017-07-23 14:10:11', 'texto21');

Insert Into correcao(email, anomalia_id) values ('email3@bd.com', 17);

Insert Into proposta_de_correcao(email, data_hora, texto) values ('email29@bd.com', '2019-09-23 14:10:11', 'texto22');

Insert Into correcao(email, anomalia_id) values ('email29@bd.com', 8);

Insert Into proposta_de_correcao(email, data_hora, texto) values ('email27@bd.com', '2019-09-13 13:10:11', 'texto23');

Insert Into correcao(email, anomalia_id) values ('email27@bd.com', 25);

Insert Into proposta_de_correcao(email, data_hora, texto) values ('email9@bd.com', '2017-07-23 15:10:11', 'texto24');

Insert Into correcao(email, anomalia_id) values ('email9@bd.com', 23);

Insert Into proposta_de_correcao(email, data_hora, texto) values ('email3@bd.com', '2016-04-23 14:10:11', 'texto25');

Insert Into correcao(email, anomalia_id) values ('email3@bd.com', 26);

Insert Into proposta_de_correcao(email, data_hora, texto) values ('email27@bd.com', '2019-09-23 14:10:11', 'texto26');

Insert Into correcao(email, anomalia_id) values ('email27@bd.com', 5);

Insert Into proposta_de_correcao(email, data_hora, texto) values ('email3@bd.com', '2019-04-23 16:10:11', 'texto27');

Insert Into correcao(email, anomalia_id) values ('email3@bd.com', 14);

Insert Into proposta_de_correcao(email, data_hora, texto) values ('email17@bd.com', '2018-04-23 13:10:11', 'texto28');

Insert Into correcao(email, anomalia_id) values ('email17@bd.com', 26);

Insert Into proposta_de_correcao(email, data_hora, texto) values ('email13@bd.com', '2019-11-23 18:10:11', 'texto29');

Insert Into correcao(email, anomalia_id) values ('email13@bd.com', 10);

