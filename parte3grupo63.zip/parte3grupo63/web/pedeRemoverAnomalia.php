<html>
    <body>
 		<h3>Id da Anomalia a remover:</h3>
		<form action="removerAnomalia.php" method="post">
		<p><input type="visible" name="id" value="<?=$_REQUEST['id']?>"/></p>
	
        <p><input type="submit" value="Validar"/></p>
		</form>
 	</body>
</html>