<html>
    <body>
 		<h3>Id do Item a remover:</h3>
		<form action="removerItem.php" method="post">
        <p><input type="visible" name="id" value="<?=$_REQUEST['id']?>"/></p>
	
        <p><input type="submit" value="Validar"/></p>
		</form>
 	</body>
</html>