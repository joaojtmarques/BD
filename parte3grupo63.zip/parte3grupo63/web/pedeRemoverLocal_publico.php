<html>
    <body>
 		<h3>Nome do Local Publico a remover:</h3>
		<form action="removerLocal_publico.php" method="post">
		<p><input type="visible" name="nome" value="<?=$_REQUEST['nome']?>"/></p>
	
        <p><input type="submit" value="Validar"/></p>
		</form>
 	</body>
</html>